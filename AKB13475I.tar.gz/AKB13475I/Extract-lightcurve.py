import sys
import os
import numpy as np

#
#  This script will refine coordinates using the PYSIS3 algorithm (Albrow et al 2009)
#


sys.path.append('/data4tb/mda45/pyDIA-master')

use_GPU = True

if use_GPU:
    from Code import DIA_GPU as DIA
else:
    from Code import DIA_CPU as DIA

from Code import c_interface_functions as CF
from Code import calibration_functions as cal

x0, y0 = (287,215)
locate_date_range = (6508.2,6508.4)

prefix = 'lens'
quality_max = 1.25
mag_err_max = 0.3
seeing_max = 7.0
sky_max = 10000



params = DIA.DS.Parameters()
params.use_GPU = use_GPU
params.n_parallel = 1
params.gain = 1.9
params.readnoise = 5.0
params.name_pattern = 'A*.fits'
params.datekey = 'PHJDMID'
params.pdeg = 1
params.sdeg = 1
params.bdeg = 1

#rparams.use_stamps = True
#rparams.nstamps = 100
#rparams.stamp_half_width = 15

params.loc_data = 'Images'
params.loc_output = 'Output-gpu'





print 'Starting photometry for',prefix,'at', (x0,y0)

dates, seeing, roundness, bgnd, signal, flux, dflux, quality, x0, y0 = \
		CF.photom_variable_star(x0,y0,params,save_stamps=True,patch_half_width=20,locate_half_width=3,locate_date_range=locate_date_range)

print 'Converged to', (x0,y0)

refmags = np.loadtxt(params.loc_output+'/ref.mags.calibrated')
refflux = np.loadtxt(params.loc_output+'/ref.flux.calibrated')
		
star_dist2 = (refmags[:,1]-x0)**2 + (refmags[:,2]-y0)**2
star_num = np.argmin(star_dist2)
		
print 'x0 y0:', x0, y0
print 'Nearest star', star_num, 'located at', refmags[star_num,1], refmags[star_num,2]
print 'Reference flux', refflux[star_num,:]
print 'Reference mag', refmags[star_num,:]

mag = 25 - 2.5*np.log10(refflux[star_num,0] + flux)
mag_err = 25 - 2.5*np.log10(refflux[star_num,0] + flux - dflux) - mag 


lightcurve_header='      Date   Delta_Flux Err_Delta_Flux     Mag  Err_Mag        Q    FWHM Roundness      Sky    Signal'

np.savetxt(prefix+'-lightcurve.dat',np.vstack((dates,flux,dflux,mag,mag_err,quality,seeing,roundness,bgnd,signal)).T, \
					fmt='%12.5f  %12.4f  %12.4f  %7.4f  % 7.4f  %6.2f  %6.2f  %5.2f  %10.2f  %8.2f', \
					header=lightcurve_header)


q = np.where( (quality < quality_max) & (mag_err < mag_err_max) & (seeing < seeing_max) & (bgnd < sky_max) )[0]

np.savetxt(prefix+'-lightcurve-filtered.dat',np.vstack((dates[q],flux[q],dflux[q], \
					mag[q],mag_err[q],quality[q],seeing[q],roundness[q],bgnd[q],signal[q])).T, \
					fmt='%12.5f  %12.4f  %12.4f  %7.4f  % 7.4f  %6.2f  %6.2f  %5.2f  %10.2f  %8.2f', \
					header=lightcurve_header)
			
cal.plot_lightcurve(prefix+'-lightcurve.dat',plotfile=prefix+'-lightcurve.png')
cal.plot_lightcurve(prefix+'-lightcurve-filtered.dat',plotfile=prefix+'-lightcurve-filtered.png')
