import sys
import os
import numpy as np

files = []
dates = []
with open('images','r') as file:
    for line in file:
        filename, date = line.split()
        files.append(filename)
        dates.append(float(date))

if not(os.path.exists('dates')):
    np.savetxt('dates',np.asarray(dates),fmt='%10.5f')


n_files = len(files)

n_stars = 0
with open('ref.flux','r') as file:
    for line in file:
        n_stars += 1

flux = np.zeros((n_stars,n_files))
flux_err = np.zeros((n_stars,n_files))

for i, f in enumerate(files):
    flux_file = f+'.flux'
    with open(flux_file,'r') as file:
        d = np.loadtxt(file)
        flux[:,i] = d[:,0]
        flux_err[:,i] = d[:,1]

np.save('flux.npy',flux)
np.save('flux_err.npy',flux_err)




