import sys
import os
import numpy as np

ZP = 25

files = []
dates = []
with open('images','r') as file:
    for line in file:
        filename, date = line.split()
        files.append(filename)
        dates.append(date)

if not(os.path.exists('dates')):
    np.savetxt('dates',np.double(np.asarray(dates)),fmt='%10.5f')


n_files = len(files)

n_stars = 0
with open('ref.flux','r') as file:
    for line in file:
        n_stars += 1

flux = np.zeros((n_stars,n_files))
flux_err = np.zeros((n_stars,n_files))

for i, f in enumerate(files):
    flux_file = f+'.flux'
    with open(flux_file,'r') as file:
        d = np.loadtxt(file)
        flux[:,i] = d[:,0]
        flux_err[:,i] = d[:,1]

np.save('flux.npy',flux)
np.save('flux_err.npy',flux_err)

rf = np.loadtxt('ref.flux.calibrated')

mag = ZP - 2.5*np.log10(np.broadcast_to(rf[:,0,np.newaxis],flux.shape)+flux)
emag = ZP - 2.5*np.log10(np.broadcast_to(rf[:,0,np.newaxis],flux.shape)+flux-flux_err) - mag

np.save('mags.npy',mag)
np.save('mags_err.npy',emag)



